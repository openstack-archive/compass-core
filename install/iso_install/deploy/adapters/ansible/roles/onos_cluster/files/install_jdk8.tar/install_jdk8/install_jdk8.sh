#!/bin/bash

mkdir /usr/lib/jvm/
tar -xzf /opt/jdk-8u51-linux-x64.tar.gz -C /usr/lib/jvm/
mv /usr/lib/jvm/jdk1.8.0_51 /usr/lib/jvm/java-8-oracle
cp -f /opt/install_jdk8/jdk* /etc/profile.d/

